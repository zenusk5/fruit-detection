import os
import sys
import cv2
import matplotlib.pyplot as plt
from ultralytics import YOLO

def main():
    print("HỆ THỐNG NHẬN DIỆN WEBCAM ĐỒ HỌA CHUẨN MATPLOTLIB")
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    
    best_model_path = os.path.join(BASE_DIR, 'runs', 'detect', 'train', 'weights', 'best.pt')

    if os.path.exists(best_model_path):
        print(f"🎯 Nạp bộ não YOLOv11s thành công: {best_model_path}")
        trained_model = YOLO(best_model_path)
    else:
        print("❌ LỖI: Không tìm thấy file weights 'best.pt'!")
        return

    cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
    if not cap.isOpened():
        print("❌ LỖI: Không mở được Webcam!")
        return

    print("\n WEBCAM ĐÃ KÍCH HOẠT THÀNH CÔNG!")
    print("👉 HƯỚNG DẪN TẮT: Hãy nhấn nút dấu [X] màu đỏ ở góc cửa sổ khung ảnh để THOÁT.")

    plt.ion()  
    fig, ax = plt.subplots(num="YOLOv11 Real-time Fruit Detection")
    ax.axis('off')  

    image_plot = None

    while cap.isOpened() and plt.fignum_exists(fig.number):
        success, frame = cap.read()
        if not success:
            break

        results = trained_model(frame, conf=0.4, device=0)
        
        annotated_frame = results[0].plot()
        rgb_frame = cv2.cvtColor(annotated_frame, cv2.COLOR_BGR2RGB)

        if image_plot is None:
            image_plot = ax.imshow(rgb_frame)
        else:
            image_plot.set_data(rgb_frame)
            
        fig.canvas.draw()
        fig.canvas.flush_events()

    cap.release()
    plt.close('all')
    print("\n HỆ THỐNG ĐÃ ĐÓNG AN TOÀN!")

if __name__ == '__main__':
    main()
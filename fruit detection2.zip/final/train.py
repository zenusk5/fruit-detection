import os
import sys
import zipfile
import torch
import shutil
from ultralytics import YOLO

def main():
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    
    old_train_dir = os.path.join(BASE_DIR, "runs")
    if os.path.exists(old_train_dir):
        try:
            shutil.rmtree(old_train_dir)
        except:
            pass

    device_id = 0 if torch.cuda.is_available() else 'cpu'

    zip_file_path = r"C:\Users\asdc3\Downloads\baitest\Fruit.yolov11.zip"
    dataset_path = os.path.join("D:\\", "fruit_dataset_clean")

    if not os.path.exists(dataset_path):
        if os.path.exists(zip_file_path):
            with zipfile.ZipFile(zip_file_path, 'r') as zip_ref:
                zip_ref.extractall(dataset_path)
        else:
            sys.exit(1)

    for root, dirs, files in os.walk(dataset_path):
        for file in files:
            if file.endswith(".cache"):
                try:
                    os.remove(os.path.join(root, file))
                except:
                    pass

    model = YOLO("yolo11s.pt") 
    yolodata_path = os.path.join(dataset_path, "data.yaml")

    model.train(
        data=yolodata_path, 
        epochs=100,
        imgsz=512,
        batch=16,
        project=BASE_DIR,
        name="runs/detect/train",
        exist_ok=True,     
        device=device_id,
        cache=False,
        plots=True,
        close_mosaic=10,
        hsv_h=0.04,
        degrees=20.0,
        scale=0.5,
        fliplr=0.5,
        mosaic=1.0
    ) 

    test_images_dir = os.path.join(dataset_path, "test", "images")
    if os.path.exists(test_images_dir):
        best_model_path = os.path.join(BASE_DIR, "runs", "detect", "train", "weights", "best.pt")
        test_model = YOLO(best_model_path)
        
        results = test_model.predict(
            source=test_images_dir,
            conf=0.35,
            save=True,
            project=BASE_DIR,
            name="runs/detect/test_predictions",
            exist_ok=True,
            device=device_id
        )
        
        total_images = len(results)
        detected_images = sum(1 for r in results if len(r.boxes) > 0)
        
        print(f" Tổng số ảnh test: {total_images}")
        print(f" Số ảnh đoán trúng: {detected_images}")
        print(f" Tỷ lệ đoán trúng: {(detected_images / total_images) * 100:.2f}%")

if __name__ == '__main__':
    main()